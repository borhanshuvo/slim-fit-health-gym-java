import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Graphics;
public class Program extends Frame implements WindowListener, ActionListener{

	private Register register;

	private Button back;
	private Button logOut;


	public Program(Register r){
		super("SlimFit Health Gym");
		this.register=r;
                ImageIcon ic=new ImageIcon(getClass().getResource("img.jpg")); 
		this.setIconImage(ic.getImage());
        Label l1=new Label("  Program name         Cost               Duration Time");
		Label l2=new Label("   Bodybuilding               10000             3 Month");
		Label l3=new Label("   Martial Art                 20000              6 Month");
		
		add(l1);
		add(l2);
		add(l3);
		
        logOut = new Button("Log Out");
        back= new Button("Back");
        add(back);
		add(logOut);
		l1.setBounds(120,40,280,30);
		l2.setBounds(120,80,600,30);
		l3.setBounds(120,120,600,30);
		
		logOut.setBounds(120,200,50,25);
                back.setBounds(300,200,50,25);
                l1.setBackground(Color.black);
		l1.setForeground(Color.WHITE);
		setSize(800,400);
		setLayout(null);
                setBackground(Color.GRAY);
		addWindowListener(this);
		logOut.addActionListener(this);
                back.addActionListener(this);
	}
		public void paint(Graphics g){
		
	}
	public void windowClosing(WindowEvent we){
        System.out.println("Window is closing");
		System.exit(0);
	}
	public void actionPerformed(ActionEvent e){
		String s=e.getActionCommand();
		if(s.equals("Log Out")){
			register.programs.setVisible(false);
			register.log.setVisible(true);
		}
                else if(s.equals("Back")){
			register.programs.setVisible(false);
			register.information.setVisible(true);
		}

	}
	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}
}