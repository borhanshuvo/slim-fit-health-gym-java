import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Graphics;

class AddMember extends Frame implements WindowListener, ActionListener{
	

	private Register register;
	public Button add;
	public Button back;
        public Button logOut;
	public TextField name;
        private ImageIcon ic;
	public TextField id;
        public TextField address;
        public TextField phone;
        public TextField balance;
	public AddMember(Register r){
		super("SlimFit Health Gym");
		this.register=r;

		ic=new ImageIcon(getClass().getResource("img.jpg")); 
		this.setIconImage(ic.getImage());
		add = new Button("Add");
		back=new Button("Back");
                logOut= new Button("Log Out");
		id= new TextField("Id");
		name = new TextField("Name");
                address = new TextField("Address");
                phone = new TextField("Phone");
                balance = new TextField("Balance");
		add(id);
		add(name);
		add(address);
		add(phone);
                add(balance);
                add(back);
                add(add);
		setSize(400,500);
		setBackground(Color.GRAY);

		setLayout(null);
	       id.setBounds(50,70,150,30);
		
		name.setBounds(50,130,150,30);

		address.setBounds(50,190,150,30);
                phone.setBounds(50,250,150,30);
                balance.setBounds(50,310,150,30);

		back.setBounds(50,370,50,20);
                add.setBounds(120,370,50,20);
		addWindowListener(this);
		back.addActionListener(this);
                add.addActionListener(this);
		
		
	}
 
	public void paint(Graphics g){

	}
	public void windowClosing(WindowEvent we){
		System.exit(0);
	}
	public void actionPerformed(ActionEvent e){
		String s=e.getActionCommand();
                DataAccess da=new DataAccess();
		if(s.equals("Back")){
                   register.memberInfo.setVisible(true);
		   register.add.setVisible(false); 
                }
                else if(s.equals("Add")){
                     String sql="insert into member (id,name,address,phone,balance) values('"+id.getText()+"','"+name.getText()+"','"+address.getText()+"','"+phone.getText()+"','"+balance.getText()+"')";
                     da.updateDB(sql);
                     System.out.println(sql);
                }
	}
	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}

}