import java.awt.*;
import java.awt.event.*;
import javax.swing.ImageIcon;
import javax.swing.JButton;
class SignUpPage extends Frame implements WindowListener,ActionListener{

	private Register register;
        private TextField id;
 
        private Button update;
	private TextField uName;
	private TextField email;
	private Button signUpButton;
	private Button backButton;
        private Button drop;

	public SignUpPage(Register r){
		super("SlimFit Health Gym");
		this.register=r;
                ImageIcon ic=new ImageIcon(getClass().getResource("img.jpg")); 
		this.setIconImage(ic.getImage());
        setBackground(Color.GRAY);		
                id = new TextField(10);
		uName=new TextField(10);
		email=new TextField(10);
                Label i = new Label("User Id: ");
		Label ul=new Label("User Name: ");
		Label el=new Label("Password: ");
		signUpButton=new Button("Signup");
             
		backButton=new Button("Back");
                add(i);
                add(id);
		add(ul);
		add(uName);
		add(el);
		add(email);
		add(signUpButton);
           
		add(backButton);
                update = new Button("Change Passwor");
                drop = new Button("delete");
                add(drop);
                add(update);
		setSize(1000,400);
		setLayout(new FlowLayout());
		addWindowListener(this);
                drop.addActionListener(this);
		backButton.addActionListener(this);
		signUpButton.addActionListener(this);
                update.addActionListener(this);
	}
	public void windowClosing(WindowEvent we){
        System.out.println("Window is closing");
		System.exit(0);
	}
	public void actionPerformed(ActionEvent e){
		String s=e.getActionCommand();
                DataAccess da=new DataAccess();
		if(s.equals("Signup")){
            String sql="insert into checking (id,uName,pass) values('"+id.getText()+"','"+uName.getText()+"','"+email.getText()+"')";
			da.updateDB(sql);
                        
			System.out.println(sql);
		}

		else if(s.equals("Back")){
			register.log.setVisible(true);
			register.sign.setVisible(false);
		}
                else if(s.equals("delete")){
 			register.row.setVisible(true);
			register.sign.setVisible(false);                   
                }
                else if(s.equals("Change Passwor")){
 			register.update.setVisible(true);
			register.sign.setVisible(false);                   
                }


	}
	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}

}