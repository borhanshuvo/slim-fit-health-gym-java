import java.awt.*;
import java.awt.event.*;
import javax.swing.ImageIcon;
import javax.swing.JButton;
class DeleteRow extends Frame implements WindowListener,ActionListener{

	private Register register;
        private TextField id;

	private Button back;

        private JButton drop;

	public DeleteRow(Register r){
		super("SlimFit Health Gym");
		this.register=r;
                ImageIcon ic=new ImageIcon(getClass().getResource("img.jpg")); 
		this.setIconImage(ic.getImage());            
                id = new TextField(10);

                Label i = new Label("User Id: ");


             
		back=new Button("Back");
                add(i);
                add(id);

           
		add(back);
                drop = new JButton("delete");
                add(drop);
		setSize(800,400);
		setLayout(new FlowLayout());
		addWindowListener(this);
                drop.addActionListener(this);
		back.addActionListener(this);

	}
	public void windowClosing(WindowEvent we){
        System.out.println("Window is closing");
		System.exit(0);
	}
	public void actionPerformed(ActionEvent e){
                DataAccess da=new DataAccess();
		String s=e.getActionCommand();


		if(s.equals("Back")){
			register.sign.setVisible(true);
			register.row.setVisible(false);
		}
                else if(s.equals("delete")){
                        String sql = "DELETE FROM checking WHERE id = "+id.getText()+" ";
			da.updateDB(sql);
                        
			System.out.println(sql);                   
                }


	}
	public void windowActivated(WindowEvent e){}
	public void windowClosed(WindowEvent e){}
	public void windowDeactivated(WindowEvent e){}
	public void windowDeiconified(WindowEvent e){}
	public void windowIconified(WindowEvent e){}
	public void windowOpened(WindowEvent e){}

}